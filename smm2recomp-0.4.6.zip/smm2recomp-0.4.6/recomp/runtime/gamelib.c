// Loads the recompiled game code library (runtime/gamelib.h).
#include "gamelib.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#endif

#include "paths.h"
#if defined(__x86_64__)
#include "platform/x86_cpu.h"
#endif
#include "rt.h"

static const GameLibTables *g_tables;
static char g_error[256];

#ifdef GAMELIB_STATIC
// iOS: the game code is part of the executable (tools/gamelib_entry.c linked in; nothing is loaded at run time)
const GameLibTables *recomp_game_tables(void);
bool gamelib_present(const char *game_dir) { (void)game_dir; return true; }
bool gamelib_load(const char *game_dir, char *why, size_t why_size) {
    (void)game_dir;
    if (!g_tables) {
        g_tables = recomp_game_tables();
        if (g_tables && (g_tables->abi != GAMELIB_ABI || strcmp(g_tables->id, GAMELIB_ID))) g_tables = NULL;
        if (g_tables) LOG("[gamelib] linked in (%llu + %llu functions)\n", (unsigned long long)*g_tables->main_count,
                          (unsigned long long)*g_tables->sdk_count);
    }
    if (!g_tables && why) snprintf(why, why_size, "the game code linked into this app was built for another version");
    return g_tables != NULL;
}
#else

// The library's id file (<library>.id, written next to it by the build): its GAMELIB_ID, read without loading it. On
// x86-64 the CPU level it was built for follows ("x86-64-v3", "x86-64-v2", "forced"; gamebuild.c): a v3 build, or one
// from before the level was written (it may be v3), needs a CPU with AVX2 / FMA / BMI2, else it is built again.
static bool id_matches(const char *lib) {
    char path[1100], id[160] = {0};
    snprintf(path, sizeof path, "%s.id", lib);
    FILE *f = fopen(path, "rb");
    if (!f) return false;
    size_t n = fread(id, 1, sizeof id - 1, f);
    fclose(f);
    while (n && (id[n - 1] == '\n' || id[n - 1] == '\r')) id[--n] = 0;
    char *level = strchr(id, ' ');
    if (level) *level++ = 0;
    if (strcmp(id, GAMELIB_ID)) return false;
#if defined(__x86_64__)
    if ((!level || !strcmp(level, "x86-64-v3")) && !x86_cpu_has_v3()) {
        LOG("[gamelib] the game code was built for a CPU with AVX2 (x86-64-v3); this one hasn't: building it again\n");
        return false;
    }
#endif
    return true;
}

static bool exists(const char *p) {
    FILE *f = fopen(p, "rb");
    if (f) fclose(f);
    return f != NULL;
}

// The places to look, in order (gamelib.h). Returns how many were filled.
static int candidates(const char *game_dir, char out[3][1100]) {
    int n = 0;
    const char *env = getenv("LARECOMP_GAME_LIB");
#ifdef __ANDROID__
    // Android: the library in the APK, by its name (the app's library path finds it; it may stay inside the APK, so
    // there is no file or id file to look at: its own id decides, as with LARECOMP_GAME_LIB)
    (void)game_dir;
    snprintf(out[n++], 1100, "%s", env && *env ? env : GAMELIB_NAME);
    return n;
#endif
    if (env && *env) snprintf(out[n++], 1100, "%s", env);
    char exe_side[1024];
    if (rt_resource(GAMELIB_NAME, NULL, exe_side, sizeof exe_side) && exists(exe_side))
        snprintf(out[n++], 1100, "%s", exe_side);
    if (game_dir) snprintf(out[n++], 1100, "%s/%s", game_dir, GAMELIB_NAME);
    return n;
}

bool gamelib_present(const char *game_dir) {
    if (g_tables) return true;
#ifdef __ANDROID__
    (void)game_dir;
    return true;  // (packaged with the app)
#endif
    char c[3][1100];
    int n = candidates(game_dir, c);
    for (int i = 0; i < n; i++)
        if (exists(c[i]) && id_matches(c[i])) return true;
    return false;
}

static const GameLibTables *open_lib(const char *path) {
#ifdef _WIN32
    HMODULE h = LoadLibraryA(path);
    if (!h) { snprintf(g_error, sizeof g_error, "can't load %s (error %lu)", path, GetLastError()); return NULL; }
    GameLibEntry entry = (GameLibEntry)(void *)GetProcAddress(h, GAMELIB_ENTRY);
#else
    void *h = dlopen(path, RTLD_NOW | RTLD_LOCAL);
    if (!h) { snprintf(g_error, sizeof g_error, "%s", dlerror()); return NULL; }
    GameLibEntry entry = (GameLibEntry)dlsym(h, GAMELIB_ENTRY);
#endif
    if (!entry) { snprintf(g_error, sizeof g_error, "%s: not game code", path); return NULL; }
    const GameLibTables *t = entry();
    if (!t || t->abi != GAMELIB_ABI || !t->id || strcmp(t->id, GAMELIB_ID)) {
        snprintf(g_error, sizeof g_error, "%s was built for another version", path);
        return NULL;  // (left loaded: nothing of it runs)
    }
    return t;
}


bool gamelib_load(const char *game_dir, char *why, size_t why_size) {
    static bool tried;
    if (!tried) {
        tried = true;
        snprintf(g_error, sizeof g_error, "the game code hasn't been built: put your game files in extracted/ (exefs, romfs), and for the first-launch "
                 "build run setup.bat / setup.sh next to the program (tools/venv; zig/ and gamelib-src/ must be there too)");
        char c[3][1100];
        int n = candidates(game_dir, c);
        const char *env = getenv("LARECOMP_GAME_LIB");
        for (int i = 0; i < n && !g_tables; i++) {
#ifdef __ANDROID__
            bool given = true;  // (a name for the dynamic linker, not a path: candidates())
            (void)env;
#else
            if (!exists(c[i])) continue;
            bool given = i == 0 && env && *env;  // LARECOMP_GAME_LIB: loaded as given, the library's own id decides
#endif
            if (!given && !id_matches(c[i])) {
                snprintf(g_error, sizeof g_error, "%s was built for another version", c[i]);
                continue;
            }
            g_tables = open_lib(c[i]);
            if (g_tables) LOG("[gamelib] %s (%llu + %llu functions)\n", c[i], (unsigned long long)*g_tables->main_count,
                              (unsigned long long)*g_tables->sdk_count);
        }
    }
    if (!g_tables && why) snprintf(why, why_size, "%s", g_error);
    return g_tables != NULL;
}

#endif  // GAMELIB_STATIC

const GameLibTables *gamelib_tables(void) { return g_tables; }
