# SMM2 Recomp: armar el APK en Termux (BETA, sin probar)

Esto arma el APK en tu teléfono. La compilación pesada del juego sigue siendo de una PC.

## 1. Lo que sacas de una PC (una sola vez)
Con el proyecto compilado en la PC, copia estas cosas a tu teléfono (por cable, Drive o WhatsApp a ti mismo):
- `recomp/build/smm2-android-arm64-0x800000000/libmain.so`
- `recomp/build/smm2-android-arm64-0x800000000/libsmm2game.so`
- `recomp/build/deps-android-arm64/lib/libSDL3.so`
- la carpeta `recomp/build/deps-android-arm64/java/` completa
- `android.jar` de `<tu SDK de Android>/platforms/android-35/android.jar`

En Termux, ponlos así:
```
~/smm2-bundle/lib/arm64-v8a/libmain.so
~/smm2-bundle/lib/arm64-v8a/libsmm2game.so
~/smm2-bundle/lib/arm64-v8a/libSDL3.so
~/smm2-bundle/java/org/libsdl/...
~/android.jar
```

## 2. En Termux
```
pkg install -y openjdk-17 aapt2 d8 apksigner zip
cd ~/smm2-termux
bash build_apk.sh ~/smm2-bundle ~/android.jar
```
Sale `SMM2Recomp.apk` dentro de `smm2-termux`. Ábrelo con el administrador de archivos y toca Instalar. Si pide permiso para instalar apps desconocidas, dáselo.

Si ya tienes instalada una versión firmada de otra forma, desinstálala primero.

## Límites
- Nada de esto se ha probado en un teléfono.
- Sin los archivos de la PC, la app se abre pero no puede jugar.
- La app no tiene icono propio.
