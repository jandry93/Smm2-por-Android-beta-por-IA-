// ImportActivity (ALPHA): the app's entry screen. Imports the game files (the folder `private/smm2` that the Mac build
// prepares: extracted/exefs, extracted/romfs, fonts, sysdata, optionally save) from a folder you pick on the phone into
// the app's own internal folder, which the runtime uses whenever extracted/exefs/main is there; then starts the game.
// Android 13+ keeps other apps out of Android/data, so the app copies into its own storage instead.
// Added to SMM2 Recomp 0.4.6 on 2026-10-24; GPL-3.0-or-later like the rest of the project. Not compiled or run by
// its author (no Android SDK where it was written): expect to fix small things.
package org.smcraft.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.StatFs;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class ImportActivity extends Activity {
    private static final int PICK = 1;
    private static final String[] REQUIRED = {"extracted/exefs", "extracted/romfs", "fonts", "sysdata"};
    private static final String[] OPTIONAL = {"save"};
    private static final String DIR = DocumentsContract.Document.MIME_TYPE_DIR;

    private TextView status;
    private ProgressBar bar;
    private Button play, pick, wipe;
    private File dest;
    private volatile boolean busy;
    private long total, done, lastUi;

    private static final class Doc {
        String id, name, mime;
        long size;
        boolean isDir() { return DIR.equals(mime); }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dest = getFilesDir();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p * 2, p, p);
        TextView title = new TextView(this);
        title.setText("SMM2 Recomp (alfa)");
        title.setTextSize(24);
        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, p, 0, p);
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setVisibility(View.GONE);
        play = new Button(this);
        play.setText("Jugar");
        play.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivity(new Intent(ImportActivity.this, org.libsdl.app.SDLActivity.class)); }
        });
        pick = new Button(this);
        pick.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(i, PICK);
            }
        });
        wipe = new Button(this);
        wipe.setText("Borrar los archivos importados");
        wipe.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(ImportActivity.this)
                    .setMessage("Se borran los archivos del juego de la app (unos 3 GB). Tu copia original no se toca. ¿Seguir?")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Borrar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            for (String s : REQUIRED) deleteTree(new File(dest, s));
                            deleteTree(new File(dest, "import_tmp"));
                            refresh();
                        }
                    }).show();
            }
        });
        root.addView(title);
        root.addView(status);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        root.addView(play, new LinearLayout.LayoutParams(-1, -2));
        root.addView(pick, new LinearLayout.LayoutParams(-1, -2));
        root.addView(wipe, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        refresh();
    }

    private String missing() {
        StringBuilder sb = new StringBuilder();
        if (!new File(dest, "extracted/exefs/main").isFile()) sb.append(" extracted/exefs");
        if (!new File(dest, "extracted/romfs").isDirectory()) sb.append(" extracted/romfs");
        if (!new File(dest, "fonts").isDirectory()) sb.append(" fonts");
        if (!new File(dest, "sysdata").isDirectory()) sb.append(" sysdata");
        return sb.toString();
    }

    private void refresh() {
        String m = missing();
        boolean ready = m.length() == 0;
        play.setEnabled(ready && !busy);
        pick.setEnabled(!busy);
        wipe.setEnabled(!busy);
        pick.setText(ready ? "Importar de nuevo" : "Elegir carpeta con el juego");
        if (!busy) {
            status.setText(ready ? "Listo: los archivos del juego están importados."
                : "Faltan:" + m + "\n\nCopia al teléfono la carpeta de datos que preparó el Mac (la que tiene extracted, fonts y sysdata), "
                + "por ejemplo a Documentos/smm2, y pulsa el botón para elegirla. No elijas la raíz de Descargas ni del almacenamiento.");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req != PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri tree = data.getData();
        busy = true;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        bar.setVisibility(View.VISIBLE);
        refresh();
        new Thread(new Runnable() {
            public void run() {
                String err = null;
                try { importFrom(tree); } catch (Exception e) { err = String.valueOf(e); }
                final String msg = err;
                runOnUiThread(new Runnable() {
                    public void run() {
                        busy = false;
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        bar.setVisibility(View.GONE);
                        refresh();
                        if (msg != null) status.setText("No se pudo importar:\n" + msg);
                    }
                });
            }
        }, "import").start();
    }

    // ---- import ---------------------------------------------------------------------------------------------

    private void importFrom(Uri tree) throws Exception {
        Doc root = new Doc();
        root.id = DocumentsContract.getTreeDocumentId(tree);
        root.mime = DIR;
        List<String> items = new ArrayList<String>();
        List<Doc> docs = new ArrayList<Doc>();
        for (String s : REQUIRED) {
            Doc d = find(tree, root, s);
            if (d == null) throw new Exception("En la carpeta elegida falta '" + s + "'. Elige la carpeta que contiene extracted, fonts y sysdata.");
            items.add(s); docs.add(d);
        }
        for (String s : OPTIONAL) {
            Doc d = find(tree, root, s);
            if (d != null) { items.add(s); docs.add(d); }
        }
        total = 0; done = 0; lastUi = 0;
        for (Doc d : docs) total += size(tree, d);
        StatFs fs = new StatFs(dest.getAbsolutePath());
        long free = fs.getAvailableBytes();
        if (free < total + (200L << 20))
            throw new Exception("Poco espacio: hacen falta unos " + gb(total + (200L << 20)) + " GB libres y hay " + gb(free) + " GB.");
        File stage = new File(dest, "import_tmp");
        deleteTree(stage);
        for (int i = 0; i < items.size(); i++) {
            copy(tree, docs.get(i), new File(stage, items.get(i)));
        }
        for (String s : items) {   // everything copied: now put it in place (the runtime only looks at the final names)
            File to = new File(dest, s);
            deleteTree(to);
            to.getParentFile().mkdirs();
            if (!new File(stage, s).renameTo(to)) throw new Exception("No se pudo mover " + s);
        }
        deleteTree(stage);
    }

    private Doc find(Uri tree, Doc from, String path) {
        Doc cur = from;
        for (String part : path.split("/")) {
            Doc next = null;
            for (Doc c : children(tree, cur.id)) if (c.name.equals(part)) { next = c; break; }
            if (next == null) return null;
            cur = next;
        }
        return cur;
    }

    private List<Doc> children(Uri tree, String parentId) {
        List<Doc> out = new ArrayList<Doc>();
        Uri q = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        String[] cols = {DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE};
        Cursor c = getContentResolver().query(q, cols, null, null, null);
        if (c == null) return out;
        try {
            while (c.moveToNext()) {
                Doc d = new Doc();
                d.id = c.getString(0); d.name = c.getString(1); d.mime = c.getString(2);
                d.size = c.isNull(3) ? 0 : c.getLong(3);
                out.add(d);
            }
        } finally { c.close(); }
        return out;
    }

    private long size(Uri tree, Doc d) {
        if (!d.isDir()) return d.size;
        long n = 0;
        for (Doc c : children(tree, d.id)) n += size(tree, c);
        return n;
    }

    private void copy(Uri tree, Doc d, File to) throws Exception {
        if (d.isDir()) {
            to.mkdirs();
            for (Doc c : children(tree, d.id)) copy(tree, c, new File(to, c.name));
            return;
        }
        to.getParentFile().mkdirs();
        Uri u = DocumentsContract.buildDocumentUriUsingTree(tree, d.id);
        InputStream in = getContentResolver().openInputStream(u);
        if (in == null) throw new Exception("No se puede leer " + d.name);
        OutputStream out = new FileOutputStream(to);
        try {
            byte[] buf = new byte[1 << 20];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                done += n;
                progress();
            }
        } finally { out.close(); in.close(); }
    }

    private void progress() {
        long now = System.currentTimeMillis();
        if (now - lastUi < 500) return;
        lastUi = now;
        final int pct = total > 0 ? (int) (done * 1000 / total) : 0;
        final String t = "Copiando… " + gb(done) + " / " + gb(total) + " GB\nNo cierres la app ni apagues la pantalla.";
        runOnUiThread(new Runnable() {
            public void run() { bar.setProgress(pct); status.setText(t); }
        });
    }

    private static String gb(long b) { return String.format(java.util.Locale.US, "%.1f", b / 1073741824.0); }

    private static void deleteTree(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }
}
