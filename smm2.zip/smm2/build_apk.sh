#!/bin/bash
# build_apk.sh: packs the APK inside Termux from a bundle made on a PC (see LEEME.md).
# usage: bash build_apk.sh <bundle folder> <android.jar>
# Uses Termux's own tools: javac (openjdk-17), d8, aapt2, zip and apksigner (the fornwall tool: keystore, input, output).
set -euo pipefail
BUNDLE=${1:?usage: bash build_apk.sh <bundle folder> <android.jar>}
JAR=${2:?usage: bash build_apk.sh <bundle folder> <android.jar>}
HERE=$(cd "$(dirname "$0")" && pwd)
W=$HERE/build
rm -rf "$W"; mkdir -p "$W/classes" "$W/dex" "$W/lib/arm64-v8a"

for f in libmain.so libsmm2game.so libSDL3.so; do
    [ -f "$BUNDLE/lib/arm64-v8a/$f" ] || { echo "Falta $BUNDLE/lib/arm64-v8a/$f (ver LEEME.md)"; exit 1; }
done
[ -d "$BUNDLE/java/org/libsdl" ] || { echo "Falta $BUNDLE/java/org/libsdl (fuentes de SDL, ver LEEME.md)"; exit 1; }
[ -f "$JAR" ] || { echo "No encuentro android.jar en $JAR"; exit 1; }

echo "1/4 compilando Java"
find "$HERE/src" "$BUNDLE/java" -name '*.java' > "$W/sources.txt"
javac --release 8 -nowarn -cp "$JAR" -d "$W/classes" @"$W/sources.txt"

echo "2/4 convirtiendo a dex"
d8 --release --min-api 24 --lib "$JAR" --output "$W/dex" $(find "$W/classes" -name '*.class')
cp "$W/dex/classes.dex" "$W/classes.dex"

echo "3/4 empaquetando"
aapt2 link -o "$W/base.apk" --manifest "$HERE/AndroidManifest.xml" -I "$JAR" \
    --min-sdk-version 24 --target-sdk-version 35
cp "$BUNDLE"/lib/arm64-v8a/*.so "$W/lib/arm64-v8a/"
(cd "$W" && zip -q -0 base.apk lib/arm64-v8a/*.so && zip -q base.apk classes.dex)

echo "4/4 firmando"
apksigner -p android "$HERE/debug.keystore" "$W/base.apk" "$HERE/SMM2Recomp.apk"
echo "Listo: $HERE/SMM2Recomp.apk"
