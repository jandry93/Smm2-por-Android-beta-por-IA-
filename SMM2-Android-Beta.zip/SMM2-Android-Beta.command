#!/bin/bash
# SMM2-Android-Beta.command (BETA): double-click launcher for android_beta.sh on macOS.
# Put this file and android_beta.sh in the project root (the folder that contains "recomp"), then double-click.
# Added to SMM2 Recomp 0.4.6 on 2026-10-24; GPL-3.0-or-later like the rest of the project.
# It asks for your folders with normal windows, remembers them, and runs android_beta.sh.
cd "$(dirname "$0")" || exit 1

pause() { echo; read -r -p "Pulsa Enter para cerrar..." _; }
die()   { echo; echo "ERROR: $*"; pause; exit 1; }

[ -d recomp ] || die "No encuentro la carpeta 'recomp'. Mueve este archivo a la carpeta principal del proyecto (smm2recomp-0.4.6)."
if [ ! -f recomp/tools/android_beta.sh ]; then
    [ -f ./android_beta.sh ] || die "Falta android_beta.sh. Ponlo junto a este archivo."
    cp ./android_beta.sh recomp/tools/android_beta.sh
fi
chmod +x recomp/tools/android_beta.sh

CONF="$HOME/.smm2-android-beta.conf"
[ -f "$CONF" ] && . "$CONF"

pick_folder() { osascript -e "POSIX path of (choose folder with prompt \"$1\")" 2>/dev/null; }
pick_file()   { osascript -e "POSIX path of (choose file with prompt \"$1\")" 2>/dev/null; }

if [ -z "${DUMP_ROOT:-}" ] || [ ! -d "$DUMP_ROOT" ]; then
    DUMP_ROOT=$(pick_folder "1/3  Carpeta con tu juego extraido (debe contener smm2-romfs, smm2-v303-exefs y smm2-v303-romfs)") || die "Cancelado."
fi
if [ -z "${FIRMWARE:-}" ] || [ ! -d "$FIRMWARE" ]; then
    FIRMWARE=$(pick_folder "2/3  Carpeta del firmware de tu consola (archivos .nca)") || die "Cancelado."
fi
if [ -z "${KEYS:-}" ] || [ ! -f "$KEYS" ]; then
    KEYS=$(pick_file "3/3  Tu archivo prod.keys (si no lo ves, pulsa Cmd+Shift+. para mostrar carpetas ocultas)") || die "Cancelado."
fi
printf 'DUMP_ROOT=%q\nFIRMWARE=%q\nKEYS=%q\n' "$DUMP_ROOT" "$FIRMWARE" "$KEYS" > "$CONF"

echo "Juego:    $DUMP_ROOT"
echo "Firmware: $FIRMWARE"
echo "Claves:   $KEYS   (se leen donde estan, no se copian)"
echo
echo "Conecta el telefono por USB con la depuracion USB activada."
read -r -p "Pulsa Enter para empezar (tarda entre 10 y 30 minutos)..." _

recomp/tools/android_beta.sh --dump-root "$DUMP_ROOT" --firmware "$FIRMWARE" --keys "$KEYS" "$@"
status=$?
echo
if [ $status -eq 0 ]; then echo "Listo. Abre SMM2 Recomp en el telefono."; else echo "Fallo (codigo $status). Copia el mensaje de arriba y pegamelo para revisarlo."; fi
pause
exit $status
